package SpaseLab.HW2_Behavioral.Iterator;

 interface Iterator {
    boolean hasNext();
    Object next();
}
