package SpaseLab.HW2_Behavioral.Visitor;

public interface Car {
    void accept(Visitor visitor);
}
