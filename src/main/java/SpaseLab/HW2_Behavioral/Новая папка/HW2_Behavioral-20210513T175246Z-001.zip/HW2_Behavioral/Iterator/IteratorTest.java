package SpaseLab.HW2_Behavioral.Iterator;

public class IteratorTest {
    public static void main(String[] args) {
        Numbers numbers = new Numbers();
        Iterator iterator = numbers.getIterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }
}
