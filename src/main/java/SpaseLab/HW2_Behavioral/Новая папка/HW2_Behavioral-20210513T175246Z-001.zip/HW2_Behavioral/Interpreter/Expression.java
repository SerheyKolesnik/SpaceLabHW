package SpaseLab.HW2_Behavioral.Interpreter;

public interface Expression {
    String interpret(Context context);
}
